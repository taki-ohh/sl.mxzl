global function EliteIconSettings_Init
void function EliteIconSettings_Init()
{
    ModSettings_AddModTitle( "精英泰坦修正设置" )
	ModSettings_AddModCategory( "泰坦图标设置" )
	ModSettings_AddEnumSetting( "ns_fd_elite_overhead_icontype", "目视泰坦图标", split( "无变化泰坦图标,精英泰坦图标,灰色泰坦图标", ",") )
	ModSettings_AddEnumSetting( "ns_fd_elite_minimap_icontype", "小地图显示图标", split( "无变化泰坦图标,精英泰坦图标,灰色泰坦图标", "," ) )
}