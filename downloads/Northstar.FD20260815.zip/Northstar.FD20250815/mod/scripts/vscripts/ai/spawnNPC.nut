untyped


global function AddCommandsNPC
global function KSpawnTitanNPC
global string Kprefixs

global int TitanGroupNPC = 0
global const currentTitanIdNPC = [						
							"npc_titan_atlas_stickybomb_boss_fd_elite",
							"npc_titan_atlas_tracker_boss_fd_elite",
							"npc_titan_atlas_vanguard_boss_fd_elite",
							"npc_titan_ogre_meteor_boss_fd_elite",
							"npc_titan_ogre_minigun_boss_fd_elite",
							"npc_titan_stryder_leadwall_boss_fd_elite",
							"npc_titan_stryder_sniper_boss_fd_elite"
							
						];


void function Kprints(entity player, string str)
{
    Chat_ServerPrivateMessage( player, Kprefixs + str, true )
}
void function AddCommandsNPC()
{
	#if SERVER
	AddClientCommandCallback("ForNPC", cycleTitanId);
	AddClientCommandCallback("ToNPC", KSpawnTitanNPC);
	
	#endif
}

bool function KSpawnTitanNPC(entity player, array<string> args)
{
#if SERVER
vector origin = GetPlayerCrosshairOrigin( player );
vector angles = player.EyeAngles();
angles.x = 0;
angles.z = 0;
string titanId = currentTitanIdNPC[TitanGroupNPC];

vector spawnPos = origin;
vector spawnAng = angles;
int team = player.GetTeam();
var teamTagPos = titanId.find( "#" )
entity npc = CreateNPCTitan( "npc_titan", team, spawnPos, spawnAng, [] );

	SetSpawnOption_Titanfall( npc )
	//SetSpawnOption_NPCTitan( npc ,TITAN_HENCH);
	
	SetSpawnOption_AISettings( npc, titanId );
	
	DispatchSpawn( npc )
	SetTitanAsElite( npc )
	
	SetEliteTitanPostSpawn( npc )
	npc.SetMaxHealth( npc.GetMaxHealth() + 12500 )
	npc.SetHealth( npc.GetMaxHealth() )
	npc.SetShieldHealthMax( 7500 )
	npc.SetShieldHealth( npc.GetShieldHealthMax() )
	npc.SetSkin( 2 )
	npc.SetCamo( 30 )
	array<entity> primaryWeapons = npc.GetMainWeapons()
	entity weapon = primaryWeapons[0]
	weapon.SetSkin( 1 )
	weapon.SetCamo( 30 )

	
	if( titanId=="npc_titan_atlas_stickybomb_boss_fd_elite")
	{   
		
		SetSpawnOption_TitanSoulPassive2( npc, "pas_ion_lasercannon" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_ion_weapon" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_ion_tripwire" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_ion_vortex" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_ion_weapon_ads" )
		npc.GetTitanSoul().soul.titanLoadout.titanExecution = "execution_random_0"
		array<entity> primaryWeapons = npc.GetMainWeapons()
		entity maingun = primaryWeapons[0]
		maingun.AddMod( "fd_split_shot_cost" )
		maingun.AddMod( "fd_balance" )
		maingun.AddMod( "pas_ion_weapon" )
		maingun.AddMod( "pas_ion_weapon_ads" )
		

		npc.GetOffhandWeapon( OFFHAND_EQUIPMENT ).AddMod( "fd_laser_cannon" )
		npc.GetOffhandWeapon( OFFHAND_EQUIPMENT ).AddMod( "fd_balance" )
		npc.GetOffhandWeapon( OFFHAND_EQUIPMENT ).AddMod( "pas_ion_lasercannon" )
		npc.GetOffhandWeapon( OFFHAND_ORDNANCE ).AddMod( "fd_balance" )
		npc.GetOffhandWeapon( OFFHAND_ORDNANCE ).AddMod( "fd_laser_upgrade" )
		npc.GetOffhandWeapon( OFFHAND_ANTIRODEO ).AddMod( "pas_ion_tripwire" )
		npc.GetOffhandWeapon( OFFHAND_SPECIAL ).AddMod( "pas_ion_vortex" )
	}
    if( titanId=="npc_titan_atlas_tracker_boss_fd_elite")
	{   
		
		SetSpawnOption_TitanSoulPassive2( npc, "pas_tone_sonar" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_tone_wall" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_tone_weapon" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_tone_rockets" )
		npc.GetTitanSoul().soul.titanLoadout.titanExecution = "execution_random_4"
		npc.GetOffhandWeapon(  OFFHAND_EQUIPMENT ).AddMod( "fd_salvo_core" )
		npc.GetOffhandWeapon( OFFHAND_SPECIAL ).AddMod( "pas_tone_wall" )
		npc.GetOffhandWeapon(  OFFHAND_ORDNANCE ).AddMod( "pas_tone_rockets" )
		entity tonesonar = npc.GetOffhandWeapon( OFFHAND_ANTIRODEO )
		tonesonar.AddMod( "fd_sonar_duration" )
		tonesonar.AddMod( "fd_sonar_damage_amp" )
		tonesonar.AddMod( "pas_tone_sonar" )
		
		array<entity> primaryWeapons = npc.GetMainWeapons()
		entity maingun = primaryWeapons[0]
		maingun.AddMod( "fast_reload" )
		maingun.AddMod( "fd_splasher_rounds" )
		maingun.AddMod( "fd_tone_weapon_2" )
		maingun.AddMod( "pas_tone_weapon" )
	}
	if( titanId=="npc_titan_atlas_vanguard_boss_fd_elite")
	{   
		
		SetSpawnOption_TitanSoulPassive2( npc, "pas_vanguard_coremeter" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_vanguard_shield" )
		//SetSpawnOption_TitanSoulPassive2( npc, "pas_vanguard_rearm" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_vanguard_doom" )
		entity soul = npc.GetTitanSoul()
	    if ( IsValid( soul ) && SoulHasPassive( soul, ePassives.PAS_VANGUARD_DOOM ))
		{
		GivePassive( soul, ePassives.PAS_VANGUARD_COREMETER )
		}
		npc.TakeOffhandWeapon( OFFHAND_ANTIRODEO )
		npc.GiveOffhandWeapon( "mp_titanability_laser_trip", OFFHAND_ANTIRODEO,["pas_ion_tripwire"] )
		npc.GetTitanSoul().soul.titanLoadout.titanExecution = "execution_vanguard"
		npc.GetTitanSoul().SetTitanSoulNetInt( "upgradeCount", 5 )
		npc.GetTitanSoul().SetTitanSoulNetInt( "upgradeCount", 8 )
		array<entity> primaryWeapons = npc.GetMainWeapons()
		entity maingun = primaryWeapons[0]
		maingun.AddMod( "arc_rounds" )
		maingun.AddMod( "rapid_reload" )
		maingun.AddMod( "fd_vanguard_weapon_1" )
		maingun.AddMod( "fd_vanguard_weapon_2" )
		maingun.AddMod( "fd_vanguard_utility_1" )
		maingun.AddMod( "fd_vanguard_utility_2" )
		
		npc.TakeOffhandWeapon( OFFHAND_ORDNANCE )
		npc.TakeOffhandWeapon( OFFHAND_EQUIPMENT)
		npc.GiveOffhandWeapon( "mp_titanweapon_shoulder_rockets", OFFHAND_ORDNANCE, ["dev_mod_low_recharge"] )
		npc.GiveOffhandWeapon( "mp_titancore_amp_core", OFFHAND_EQUIPMENT,["vanguard_amp_core"] )
		//npc.GiveOffhandWeapon( "mp_titancore_salvo_core", OFFHAND_EQUIPMENT, ["fd_salvo_core"] )
		
		entity shieldLaser = npc.GetOffhandWeapon( OFFHAND_SPECIAL )
		shieldLaser.AddMod( "energy_field_energy_transfer" )
	}
	if( titanId=="npc_titan_ogre_meteor_boss_fd_elite")
	{   
		
		SetSpawnOption_TitanSoulPassive2( npc, "pas_scorch_flamecore" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_scorch_selfdmg" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_scorch_weapon" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_scorch_shield" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_scorch_firewall" )
		npc.GetTitanSoul().soul.titanLoadout.titanExecution = "execution_random_1"
		
		array<entity> primaryWeapons = npc.GetMainWeapons()
		entity weapon = primaryWeapons[0]
		weapon.AddMod( "fd_wpn_upgrade_2" )
		weapon.AddMod( "fd_fire_damage_upgrade" )
		weapon.AddMod( "fd_hot_streak" )
		weapon.AddMod( "pas_scorch_weapon" )
		npc.GetOffhandWeapon( OFFHAND_ANTIRODEO ).AddMod( "fd_explosive_barrel" )
		npc.GetOffhandWeapon( OFFHAND_SPECIAL ).AddMod( "pas_scorch_shield" )
		npc.GetOffhandWeapon( OFFHAND_ORDNANCE ).AddMod( "pas_scorch_firewall" )
		npc.GetOffhandWeapon( OFFHAND_EQUIPMENT ).AddMod( "pas_scorch_flamecore" )
		npc.GetOffhandWeapon( OFFHAND_EQUIPMENT ).AddMod( "elite_scorch_core" )
	}
	if ( titanId=="npc_titan_ogre_minigun_boss_fd_elite")
	{   
		
		SetSpawnOption_TitanSoulPassive2( npc, "pas_legion_spinup" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_legion_weapon" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_legion_gunshield" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_legion_chargeshot" )
		npc.GetTitanSoul().soul.titanLoadout.titanExecution = "execution_random_5"
		npc.TakeOffhandWeapon( OFFHAND_EQUIPMENT )
		npc.GiveOffhandWeapon( "mp_titancore_flame_wave", OFFHAND_EQUIPMENT, ["pas_scorch_flamecore","elite_legion_core"] )
		
		array<entity> primaryWeapons = npc.GetMainWeapons()
		entity maingun = primaryWeapons[0]
		maingun.AddMod( "fd_closerange_helper" )
		maingun.AddMod( "fd_longrange_helper" )
		maingun.AddMod( "fd_piercing_shots" )
		maingun.AddMod( "fd_CloseRangePowerShot" )
		maingun.AddMod( "fd_LongRangePowerShot" )
		maingun.AddMod( "fd_gun_shield_redirect" )
		maingun.AddMod( "SiegeMode" )
		maingun.AddMod( "fd_gun_shield")
		maingun.AddMod( "pas_legion_weapon" )
		maingun.AddMod( "pas_legion_spinup" )
		maingun.AddMod( "pas_legion_gunshield" )
		maingun.AddMod( "pas_legion_chargeshot" )

		entity power_gunshot = npc.GetOffhandWeapon ( OFFHAND_ORDNANCE)
		power_gunshot.AddMod( "pas_legion_chargeshot")
		power_gunshot.AddMod( "SiegeMode")

		entity gunshield = npc.GetOffhandWeapon( OFFHAND_SPECIAL )
		gunshield.AddMod( "npc_more_shield" )
		gunshield.AddMod( "npc_infinite_shield" )
		gunshield.AddMod( "fd_gun_shield" )
		gunshield.AddMod( "fd_gun_shield_redirect" )
		gunshield.AddMod( "SiegeMode" )
	}	
	if( titanId=="npc_titan_stryder_leadwall_boss_fd_elite")
	{   
		
		SetSpawnOption_TitanSoulPassive2( npc, "pas_ronin_swordcore" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_ronin_weapon" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_ronin_phase" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_ronin_arcwave" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_ronin_autoshift" )
		
		
		npc.GetTitanSoul().soul.titanLoadout.titanExecution = "execution_random_3"
		
		array<entity> primaryWeapons = npc.GetMainWeapons()
		entity maingun = primaryWeapons[0]
		maingun.AddMod( "pas_ronin_weapon" )
		npc.GetOffhandWeapon( OFFHAND_MELEE ).AddMod( "fd_sword_upgrade" )
		npc.GetOffhandWeapon( OFFHAND_MELEE ).AddMod( "modelset_prime" )
		npc.GetOffhandWeapon( OFFHAND_SPECIAL ).AddMod( "fd_sword_block" )
		npc.GetOffhandWeapon( OFFHAND_SPECIAL ).AddMod( "modelset_prime" )
		npc.GetOffhandWeapon(  OFFHAND_ANTIRODEO ).AddMod( "pas_ronin_phase" )
		npc.GetOffhandWeapon(  OFFHAND_ANTIRODEO ).AddMod( "fd_phase_charges" )
		npc.GetOffhandWeapon(  OFFHAND_ANTIRODEO ).AddMod( "fd_phase_distance" )
		npc.GetOffhandWeapon(  OFFHAND_ANTIRODEO ).AddMod( "pas_ronin_autoshift" )
		npc.GetOffhandWeapon(  OFFHAND_ORDNANCE ).AddMod( "pas_ronin_arcwave" )
		
		npc.GetOffhandWeapon(  OFFHAND_EQUIPMENT ).AddMod( "fd_duration" )
	}
	if( titanId=="npc_titan_stryder_sniper_boss_fd_elite")
	{  
		
		SetSpawnOption_TitanSoulPassive2( npc, "pas_northstar_cluster" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_northstar_trap" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_northstar_optics" )
		SetSpawnOption_TitanSoulPassive2( npc, "pas_northstar_weapon" )
		npc.GetTitanSoul().soul.titanLoadout.titanExecution = "execution_random_2"
		
		array<entity> primaryWeapons = npc.GetMainWeapons()
		entity maingun = primaryWeapons[0]
		maingun.AddMod( "power_shot" )
		maingun.AddMod( "fast_reload" )
		maingun.AddMod( "pas_northstar_weapon" )
		maingun.AddMod( "fd_upgrade_charge" )
		maingun.AddMod( "pas_northstar_optics")
		
		
		entity tethertrap = npc.GetOffhandWeapon( OFFHAND_SPECIAL )
		tethertrap.AddMod( "fd_trap_charges" )
		tethertrap.AddMod( "fd_explosive_trap" )
		tethertrap.AddMod( "pas_northstar_trap" )
		
		entity clustermissile = npc.GetOffhandWeapon( OFFHAND_ORDNANCE )
		clustermissile.AddMod( "pas_northstar_cluster" )
		clustermissile.AddMod( "fd_twin_cluster" )
		clustermissile.AddMod( "dev_mod_low_recharge" )
		clustermissile.AddMod( "burn_mod_titan_dumbfire_rockets" )
	}
	
	#endif
	return true;
}

bool function cycleTitanId(entity player, array<string> args)
{
	TitanGroupNPC++;
	if (TitanGroupNPC == 7) {
	TitanGroupNPC = 0; }

	#if SERVER
	Kprints( player, currentTitanIdNPC[TitanGroupNPC]);
	#endif
	return true;
}


