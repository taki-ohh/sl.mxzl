
global function OnWeaponPrimaryAttack_titanweapon_tether_trap
global function OnWeaponOwnerChanged_titanweapon_tether_trap

//const NUM_TETHERS = 2
const TETHERS_MAX = 32

#if SERVER
global function OnWeaponNpcPrimaryAttack_titanweapon_tether_trap
#endif

var function OnWeaponPrimaryAttack_titanweapon_tether_trap( entity weapon, WeaponPrimaryAttackParams attackParams )
{
	bool shouldPredict = weapon.ShouldPredictProjectiles()

	weapon.EmitWeaponNpcSound( LOUD_WEAPON_AI_SOUND_RADIUS_MP, 0.2 )

	bool shouldCreateProjectile = (IsServer() || shouldPredict)
	if ( shouldCreateProjectile )
	{
		entity weaponOwner = weapon.GetWeaponOwner()

		if ( weaponOwner.IsPlayer() )
			PlayerUsedOffhand( weaponOwner, weapon )

		vector up = weaponOwner.GetUpVector()
		vector right = weaponOwner.GetRightVector()
		array<vector> attackOffsets

		int numTethers
		if ( weapon.HasMod( "pas_northstar_trap" ) || IsSingleplayer() )
		{
			numTethers = 4
			attackOffsets.append( up * 0.31 + right * -0.21 )
			attackOffsets.append( up * 0.32 + right * 0.21 )
			attackOffsets.append( up * 0.33 + right * -0.22 )
			attackOffsets.append( up * 0.34 + right * 0.22 )
			//attackOffsets.append( up * 0.35 + right * -0.23 )
			//attackOffsets.append( up * 0.36 + right * 0.23 )
			//attackOffsets.append( up * 0.37 + right * -0.24 )
			//attackOffsets.append( up * 0.38 + right * 0.24 )
			//attackOffsets.append( up * 0.3 + right * -0.2 )
			//attackOffsets.append( up * 0.3 + right * 0.2 )
		}
		else
		{
			numTethers = 2
			attackOffsets.append( up * 0.31 + right * -0.21 )
			attackOffsets.append( up * 0.32 + right * 0.21 )
			//attackOffsets.append( up * 0.33 + right * -0.22 )
			//attackOffsets.append( up * 0.34 + right * 0.22 )
			//attackOffsets.append( up * 0.0 + right * 0.0 )
		}

		Assert( numTethers <= attackOffsets.len(), "not enough attack offsets" )
		for ( int i = 0; i < numTethers; i++ )
		{
			vector attackDir = Normalize( attackParams.dir + attackOffsets[i] )
			entity projectile = FireTether( weapon, attackParams.pos, attackDir, shouldPredict ? PROJECTILE_PREDICTED : PROJECTILE_NOT_PREDICTED, 1250 )
			if ( projectile )
			{
				#if SERVER
				SetCustomSmartAmmoTarget( projectile, true ) // prevent friendly target lockon
				projectile.e.spawnTime = Time()
				projectile.e.noOwnerFriendlyFire = true
				AddEntityCallback_OnDamaged(projectile,RemoveTeamDamage)//绊线不会被自己和队友打掉
				#endif
			}
		}
	}

	return weapon.GetAmmoPerShot()
}


#if SERVER
void function RemoveTeamDamage( entity ent, var damageInfo )
{
	entity attacker = DamageInfo_GetAttacker( damageInfo )
	if(attacker.GetTeam()==ent.GetTeam())
		DamageInfo_SetDamage( damageInfo,0 )
}
var function OnWeaponNpcPrimaryAttack_titanweapon_tether_trap( entity weapon, WeaponPrimaryAttackParams attackParams )
{
	OnWeaponPrimaryAttack_titanweapon_tether_trap( weapon, attackParams )
}
#endif

void function OnWeaponOwnerChanged_titanweapon_tether_trap( entity weapon, WeaponOwnerChangedParams changeParams )
{
	#if SERVER
	entity owner = weapon.GetWeaponOwner()

	if ( owner == null )
		return
	#endif
}